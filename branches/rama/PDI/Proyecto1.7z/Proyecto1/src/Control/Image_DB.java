/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.io.File;

/**
 *
 * @author Marvin
 */
public class Image_DB {

    private String path;
    private double red;
    private double green;
    private double blue;
    private File file;

    public double getBlue() {
        return blue;
    }

    public double getGreen() {
        return green;
    }

    public double getRed() {
        return red;
    }

    /**
     * Get the file
     *
     * @return the file
     */
    public File getFile() {
        return file;
    }

    /**
     * Contructor cuando se obtiene desde una carpeta
     *
     * @param promedio Promedio
     * @param file Arvhivo
     */
    public Image_DB(File file, double red, double green, double blue) {
        this.file = file;
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    /**
     * Set the value of file
     *
     * @param file new value of file
     */
    public void setFile(File file) {
        this.file = file;
    }

    /**
     * Contructor para cuando se obtenga el resultado en la db
     *
     * @param path Ubicacion del archivo
     * @param promedio Promedio
     */
    public Image_DB(double red, double green, double blue, String path) {
        this.path = path;
        this.red = red;
        this.green = green;
        this.blue = blue;
        this.file = new File(this.path);
    }

    /**
     * Renorna la ubicacion
     *
     * @return Ubicacion
     */
    public String getPath() {
        return path;
    }

    /**
     * Ingreso la ubicacion
     *
     * @param path Ubicacion
     */
    public void setPath(String path) {
        this.path = path;
    }
}
