/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.io.File;
import java.sql.*;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Irena
 */
public class BD {
    public static void main(String[] args) throws Exception {
        Class.forName("org.sqlite.JDBC");
        
        JFileChooser jFileChooser = new JFileChooser();
        
        File file = null;

        jFileChooser.setDialogType(JFileChooser.OPEN_DIALOG);
        

        int seleccion = jFileChooser.showDialog(null, null);

        if (seleccion == JFileChooser.APPROVE_OPTION) {
            file = jFileChooser.getSelectedFile();
        } else if (seleccion == JFileChooser.ERROR_OPTION) {
            JOptionPane.showMessageDialog(null, "Error abriendo el archivo");
        }
        
        Connection conn = DriverManager.getConnection("jdbc:sqlite:"+file.getCanonicalPath());
        Statement stat = conn.createStatement();
        //stat.executeUpdate("drop table if exists people;");
        //stat.executeUpdate("create table people (name, occupation);");
        /*PreparedStatement prep = conn.prepareStatement("insert into people values (?, ?);");

        prep.setString(1, "Gandhi");
        prep.setString(2, "politics");
        prep.addBatch();
        prep.setString(1, "Turing");
        prep.setString(2, "computers");
        prep.addBatch();
        prep.setString(1, "Wittgenstein");
        prep.setString(2, "smartypants");
        prep.addBatch();

        conn.setAutoCommit(false);
        prep.executeBatch();
        conn.setAutoCommit(true);
        */
        ResultSet rs = stat.executeQuery("select * from imagenes;");
        while (rs.next()) {
            //System.out.println("name = " + rs.getString("name"));
            System.out.println("imagen = " + rs.getString("path"));
        }
        rs.close();
        conn.close();
    }
}