/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.io.File;

/**
 *
 * @author Marvin
 */
public class Bloque {

    public int min[], max[];

    /**
     * Actualizo la imagen que este bloque usara para el mosaico (por el momento solo la dirreccion)
     * @param imagen
     */
    public void setImagen(File imagen) {
        this.imagen = imagen;
    }
    private File imagen;

    public File getImagen() {
        return imagen;
    }
    private double red, green, blue;

    public double getBlue() {
        return blue;
    }

    public double getGreen() {
        return green;
    }

    public double getRed() {
        return red;
    }
    private int pixels;

    /**
     * Aqui yo acumulo los valores de los pixeles de cada bloque para el promedio
     * @param red
     * @param green
     * @param blue
     */
    public void agregarPixel(double red, float green, float blue) {
        this.red += red;
        this.green += green;
        this.blue += blue;
        ++this.pixels;
    }

    /**
     * Realizo el calculo del promedio
     */
    public void sacarPromedio() {
        //this.promedio = this.red * 0.3 + this.green * 0.59 + this.blue * 0.11;
        red /= pixels;
        green /= pixels;
        blue /= pixels;
    }

    /**
     * Contrucctor del bloque
     *
     * @param min Punto inicial del bloque en la imagen de salida
     * @param max Punto final del bloque en la imagen de salida
     */
    public Bloque(float[] min, float[] max) {
        this.min = new int[2];
        this.max = new int[2];
        
        this.min[0] = ((min[0]-(int)min[0])>=0.5)?(int)min[0]+1:(int)min[0];
        this.min[1] = ((min[1]-(int)min[0])>=0.5)?(int)min[1]+1:(int)min[1];
        this.max[0] = ((max[0]-(int)max[0])>=0.5)?(int)max[0]+1:(int)max[0];
        this.max[1] = ((max[1]-(int)max[1])>=0.5)?(int)max[1]+1:(int)max[1];

        this.pixels = 0;
    }
}
