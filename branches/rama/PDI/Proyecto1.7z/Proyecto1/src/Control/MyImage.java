/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author Marvin
 */
public class MyImage {

    private Bloque[][] sub_imagenes;
    private BufferedImage imagen;
    private int width;
    private int height;
    private int width_s;
    private int height_s;
    private int sub_w;
    private int sub_h;

    /**
     * Constructor
     *
     * @param imagen Contiene la ubicación de la imagen
     * @param sub_w Cantidad de bloques en el ancho
     * @param sub_h Cantidad de bloques en el alto
     */
    public MyImage(BufferedImage imagen, int sub_w, int sub_h) {
        this.imagen = imagen;
        width = this.imagen.getWidth();
        height = this.imagen.getHeight();
        width_s = this.imagen.getWidth();
        height_s = this.imagen.getHeight();
        this.sub_w = sub_w;
        this.sub_h = sub_h;
        //calcularSubImagenes();


    }

    public void asignar_Rutas(ArrayList<Image_DB> imagenes_carpeta) {
        double aux = 10000000000000000.d, aux2 = 10000000000000000.d;
        Image_DB pos = null;
        Iterator<Image_DB> k = imagenes_carpeta.iterator();
        Image_DB auxi = null;
        for (int i = 0; i < sub_w; i++) {
            for (int j = 0; j < sub_h; j++) {
                while (k.hasNext()){
                //for (int k = 0; k < imagenes_carpeta.length; k++) {
                    auxi = k.next();
                    //if (imagenes_carpeta[k] != null) {
                    aux2 = Math.sqrt(Math.pow(auxi.getRed() - sub_imagenes[i][j].getRed(),2) + Math.pow(auxi.getGreen() - sub_imagenes[i][j].getGreen(),2) + Math.pow(auxi.getBlue() - sub_imagenes[i][j].getBlue(),2));
                    //}
                    if (aux > aux2) {
                        aux = aux2;
                        pos = auxi;
                    }
                }
                sub_imagenes[i][j].setImagen(pos.getFile());
                aux = 10000000000000000.d;
                //aux2 = 10000000000000000.d;
                k = imagenes_carpeta.iterator();
                pos = null;
            }
        }
    }

    public void calcularSubImagenes(int width, int height, int sub_w, int sub_h) {
        this.sub_w = sub_w;
        this.sub_h = sub_h;
        this.height_s = height;
        this.width_s = width;

        float dw = (float) width / (float) sub_w;
        float dh = (float) height / (float) sub_h;
        float min[] = {0, 0};
        float max[] = {0, 0};

        float x = 0, y = 0;
        sub_imagenes = new Bloque[sub_w][sub_h];
        //creando
        for (int i = 0; i < sub_w; i++) {
            min[0] = x;
            max[0] = x + dw - 1;
            for (int j = 0; j < sub_h; j++) {
                min[1] = y;
                max[1] = y + dh - 1;
                sub_imagenes[i][j] = new Bloque(min, max);
                y += dh;
            }
            y = 0;
            x += dw;
        }

        int aux1, aux2;
        Raster raster = imagen.getData();
        dw = (float) this.width / (float) sub_w;
        dh = (float) this.height / (float) sub_h;
        for (int i = 0; i < this.width; i++) {
            for (int j = 0; j < this.height; j++) {
                aux1 = (int) (i / dw);
                aux2 = (int) (j / dh);
                if (aux2 >= sub_h) {
                    aux2--;
                }
                if (aux1 >= sub_w) {
                    aux1--;
                }
                sub_imagenes[aux1][aux2].agregarPixel(raster.getSample(i, j, 0), raster.getSample(i, j, 1), raster.getSample(i, j, 2));
            }
        }

        for (int i = 0; i < sub_w; i++) {
            for (int j = 0; j < sub_h; j++) {
                sub_imagenes[i][j].sacarPromedio();
            }
        }
    }

    public BufferedImage imagenFinal() {

        BufferedImage salida = new BufferedImage(width_s, height_s, BufferedImage.TYPE_INT_BGR);
        Graphics dibujo = salida.getGraphics();
        Image aux;
        //dibujo.drawImage(imagen, 0, 0, null);
        int w, h;
        for (int i = 0; i < sub_w; i++) {
            for (int j = 0; j < sub_h; j++) {
                w = sub_imagenes[i][j].max[0] - sub_imagenes[i][j].min[0] + 1;
                h = sub_imagenes[i][j].max[1] - sub_imagenes[i][j].min[1] + 1;
                try {
                    aux = ImageIO.read(sub_imagenes[i][j].getImagen()).getScaledInstance(w, h, Image.SCALE_FAST);
                    dibujo.drawImage(aux, sub_imagenes[i][j].min[0], sub_imagenes[i][j].min[1], null);
                } catch (IOException ex) {
                    Logger.getLogger(MyImage.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

        return salida;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }
}