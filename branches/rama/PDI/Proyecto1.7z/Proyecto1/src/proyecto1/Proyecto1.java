/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

import javax.swing.JOptionPane;
import Interfaz.Principal;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author Marvin
 */
public class Proyecto1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            try {
                JOptionPane.showMessageDialog(null, "Tema principal no soportado pasando al tema Metal");
                javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex1) {
                
            }
        }
        Principal p = new Principal();
        p.setVisible(true);
        p.setLocationRelativeTo(null);
    }
}
